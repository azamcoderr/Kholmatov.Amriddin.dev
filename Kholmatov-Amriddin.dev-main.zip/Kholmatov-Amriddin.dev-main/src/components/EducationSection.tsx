import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { GraduationCap, Award, Calendar } from "lucide-react";

const EducationSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const education = [
    {
      institution: "PDP Academy",
      degree: "Web Frontend Development",
      period: "2021 - 2022",
      description: "Professional web frontend dasturlash kursi. HTML, CSS, JavaScript va zamonaviy framework'larni o'rgandim.",
      certificates: 2,
    },
    {
      institution: "TATU",
      degree: "Audiovisual",
      period: "2023 - Hozir",
      description: "Toshkent Axborot Texnologiyalari Universiteti. Audiovizual texnologiyalar yo'nalishi bo'yicha tahsil olmoqdaman.",
      certificates: null,
    },
  ];

  return (
    <section id="education" className="py-24 relative bg-secondary/30" ref={ref}>
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-mono text-sm">04.</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2">
            Ta'lim
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto mt-4 rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {education.map((edu, index) => (
            <motion.div
              key={edu.institution}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.2 }}
              whileHover={{ y: -5 }}
              className="glass-card p-8 group hover:glow-border transition-all duration-300"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                  <GraduationCap className="w-7 h-7 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold group-hover:text-primary transition-colors">
                    {edu.institution}
                  </h3>
                  <p className="text-muted-foreground mt-1">{edu.degree}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
                <Calendar className="w-4 h-4 text-primary" />
                <span className="font-mono">{edu.period}</span>
              </div>

              <p className="text-muted-foreground mt-4 text-sm leading-relaxed">
                {edu.description}
              </p>

              {edu.certificates && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.6 + index * 0.2 }}
                  className="flex items-center gap-3 mt-6 p-4 rounded-lg bg-primary/5 border border-primary/20"
                >
                  <Award className="w-5 h-5 text-primary" />
                  <span className="text-sm">
                    <span className="font-semibold gradient-text">{edu.certificates}</span>
                    <span className="text-muted-foreground"> ta sertifikat olindi</span>
                  </span>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EducationSection;
