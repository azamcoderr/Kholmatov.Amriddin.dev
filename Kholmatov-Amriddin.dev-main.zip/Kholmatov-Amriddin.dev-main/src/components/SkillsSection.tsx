import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const SkillsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const technicalSkills = [
    { name: "HTML", level: 95, color: "from-orange-400 to-orange-600" },
    { name: "CSS / Sass", level: 90, color: "from-blue-400 to-blue-600" },
    { name: "JavaScript", level: 85, color: "from-yellow-400 to-yellow-600" },
    { name: "Bootstrap", level: 88, color: "from-purple-400 to-purple-600" },
    { name: "Git / GitHub", level: 80, color: "from-gray-400 to-gray-600" },
  ];

  const professionalSkills = [
    { name: "Web Programmer", level: 85 },
    { name: "Project Manager", level: 90 },
  ];

  return (
    <section id="skills" className="py-24 relative bg-secondary/30" ref={ref}>
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-mono text-sm">02.</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2">
            Ko'nikmalar
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto mt-4 rounded-full" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Technical Skills */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <span className="text-primary font-mono">&lt;</span>
              Texnik Ko'nikmalar
              <span className="text-primary font-mono">/&gt;</span>
            </h3>
            <div className="space-y-6">
              {technicalSkills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, x: -30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-primary font-mono text-sm">{skill.level}%</span>
                  </div>
                  <div className="skill-bar">
                    <motion.div
                      className="skill-bar-fill"
                      initial={{ width: 0 }}
                      animate={isInView ? { width: `${skill.level}%` } : {}}
                      transition={{ duration: 1, delay: 0.5 + index * 0.1, ease: "easeOut" }}
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Professional Skills */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <span className="text-primary font-mono">&lt;</span>
              Professional Ko'nikmalar
              <span className="text-primary font-mono">/&gt;</span>
            </h3>
            <div className="grid gap-6">
              {professionalSkills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.5 + index * 0.15 }}
                  className="glass-card p-6 relative overflow-hidden group hover:glow-border transition-all duration-300"
                >
                  {/* Background progress */}
                  <motion.div
                    className="absolute inset-0 bg-primary/5"
                    initial={{ width: 0 }}
                    animate={isInView ? { width: `${skill.level}%` } : {}}
                    transition={{ duration: 1.2, delay: 0.6 + index * 0.15, ease: "easeOut" }}
                  />
                  
                  <div className="relative z-10 flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-lg">{skill.name}</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        {skill.name === "Web Programmer" 
                          ? "Frontend Development, UI/UX" 
                          : "Team Leadership, Agile"}
                      </p>
                    </div>
                    <div className="relative w-20 h-20">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                        <path
                          d="M18 2.0845
                            a 15.9155 15.9155 0 0 1 0 31.831
                            a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="hsl(var(--muted))"
                          strokeWidth="2"
                        />
                        <motion.path
                          d="M18 2.0845
                            a 15.9155 15.9155 0 0 1 0 31.831
                            a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="hsl(var(--primary))"
                          strokeWidth="2"
                          strokeLinecap="round"
                          initial={{ strokeDasharray: "0 100" }}
                          animate={isInView ? { strokeDasharray: `${skill.level} 100` } : {}}
                          transition={{ duration: 1.5, delay: 0.7 + index * 0.15, ease: "easeOut" }}
                        />
                      </svg>
                      <span className="absolute inset-0 flex items-center justify-center text-lg font-bold gradient-text">
                        {skill.level}%
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Tech icons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="mt-8 glass-card p-6"
            >
              <p className="text-sm text-muted-foreground mb-4 font-mono">// Texnologiyalar</p>
              <div className="flex flex-wrap gap-3">
                {["HTML5", "CSS3", "Sass", "Bootstrap", "JavaScript", "Git"].map((tech, i) => (
                  <motion.span
                    key={tech}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ duration: 0.3, delay: 0.9 + i * 0.05 }}
                    className="px-4 py-2 rounded-lg bg-secondary text-sm font-mono hover:bg-primary hover:text-primary-foreground transition-colors cursor-default"
                  >
                    {tech}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
