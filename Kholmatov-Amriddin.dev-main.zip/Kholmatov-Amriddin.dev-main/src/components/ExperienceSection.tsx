import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Briefcase, Users, Code, ArrowRight } from "lucide-react";

const ExperienceSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const experiences = [
    {
      title: "Project Manager & Web Developer",
      company: "B2B Marketing",
      description: "Yirik kompaniyada loyiha menejeri va web dasturchi sifatida ishladim. Kompaniyaning yangi veb-saytini yaratishda 6-10 nafarli dasturchilar guruhiga rahbarlik qildim.",
      icon: Briefcase,
      highlights: ["Team Leadership", "Web Development", "Project Management"],
    },
    {
      title: "B2B Marketing Manager",
      company: "Just Grant Program",
      description: "Konsalting firmada prezenter va B2B marketing menejeri sifatida ishladim. Boshqa maslahat firmalarini hamkorlikka taklif qilish, uchrashuvlar tashkil etish va shartnomalar tuzish bo'yicha ish olib bordim.",
      icon: Users,
      highlights: ["B2B Sales", "Client Relations", "Contract Negotiation"],
    },
    {
      title: "Freelance Web Developer",
      company: "Freelancer",
      description: "Internet saytlaridan asosan web dasturlash buyurtmalarini oldim. Turli mijozlar uchun veb-saytlar yaratish va qo'llab-quvvatlash xizmatlarini ko'rsatdim.",
      icon: Code,
      highlights: ["Client Projects", "Responsive Design", "Custom Solutions"],
    },
  ];

  return (
    <section id="experience" className="py-24 relative" ref={ref}>
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-mono text-sm">03.</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2">
            Ish Tajribasi
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto mt-4 rounded-full" />
        </motion.div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 md:left-1/2 transform md:-translate-x-px top-0 bottom-0 w-0.5 bg-border hidden md:block" />

          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <motion.div
                key={exp.title}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.2 }}
                className={`relative flex flex-col md:flex-row gap-8 ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                {/* Timeline dot */}
                <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-4 h-4">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={isInView ? { scale: 1 } : {}}
                    transition={{ duration: 0.5, delay: 0.4 + index * 0.2 }}
                    className="w-4 h-4 rounded-full bg-primary glow-border"
                  />
                </div>

                {/* Content */}
                <div className={`flex-1 ${index % 2 === 0 ? "md:pr-12" : "md:pl-12"}`}>
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="glass-card p-8 group hover:glow-border transition-all duration-300"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                        <exp.icon className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold group-hover:text-primary transition-colors">
                          {exp.title}
                        </h3>
                        <p className="text-primary font-mono text-sm mt-1">{exp.company}</p>
                      </div>
                    </div>

                    <p className="text-muted-foreground mt-4 leading-relaxed">
                      {exp.description}
                    </p>

                    <div className="flex flex-wrap gap-2 mt-4">
                      {exp.highlights.map((highlight) => (
                        <span
                          key={highlight}
                          className="px-3 py-1 text-xs rounded-full bg-secondary text-secondary-foreground"
                        >
                          {highlight}
                        </span>
                      ))}
                    </div>

                    <motion.div
                      className="flex items-center gap-2 mt-4 text-primary text-sm opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <span className="font-mono">Batafsil</span>
                      <ArrowRight className="w-4 h-4" />
                    </motion.div>
                  </motion.div>
                </div>

                {/* Spacer for alternating layout */}
                <div className="flex-1 hidden md:block" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
