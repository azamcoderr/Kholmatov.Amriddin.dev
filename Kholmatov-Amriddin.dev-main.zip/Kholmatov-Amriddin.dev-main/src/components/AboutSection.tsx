import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { User, Calendar, Award, Briefcase } from "lucide-react";
import aboutBg from "@/assets/about-bg.png";

const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stats = [
    { icon: Calendar, label: "Yosh", value: "21" },
    { icon: Award, label: "Sertifikat", value: "2" },
    { icon: Briefcase, label: "Tajriba", value: "2 yil" },
    { icon: User, label: "Daraja", value: "Middle" },
  ];

  return (
    <section id="about" className="py-24 relative" ref={ref}>
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src={aboutBg} 
          alt="About background" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
      </div>
      <div className="section-container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-mono text-sm">01.</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2">
            Men haqimda
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto mt-4 rounded-full" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            <div className="glass-card p-8 space-y-4">
              <p className="text-muted-foreground leading-relaxed">
                Men 21 yoshdaman. PDP IT Akademiyasini tugatganman va 2 ta sertifikatga egaman. 
                Dasturlash sohasida 2 yillik tajribaga egaman.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Darajam Middle bo'lib, hozirgacha 3 ta yirik kompaniyalarda ishlaganman. 
                Web dasturlash va loyiha boshqarish bo'yicha keng tajribaga egaman.
              </p>
              <div className="pt-4">
                <p className="text-sm text-primary font-mono mb-2">// Qiziqishlarim</p>
                <div className="flex flex-wrap gap-2">
                  {["Web Development", "UI/UX", "Project Management", "Team Leadership"].map((interest) => (
                    <span
                      key={interest}
                      className="px-3 py-1 text-xs rounded-full bg-secondary text-secondary-foreground"
                    >
                      {interest}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Stats grid */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-2 gap-4"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
                className="glass-card p-6 text-center group hover:glow-border transition-all duration-300"
              >
                <stat.icon className="w-8 h-8 text-primary mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <p className="text-3xl font-bold gradient-text">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
